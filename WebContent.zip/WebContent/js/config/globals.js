var g_baseviewmodel = null; //initialized in binder
var g_currentpage = null; //initialized in binder
var g_jwt = null;